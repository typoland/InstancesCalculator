//
//  InstancesGenerator.h
//  InstancesGenerator
//
//  Created by Łukasz Dziedzic on 15/10/2019.
//  Copyright © 2019 Łukasz Dziedzic. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for InstancesGenerator.
FOUNDATION_EXPORT double InstancesGeneratorVersionNumber;

//! Project version string for InstancesGenerator.
FOUNDATION_EXPORT const unsigned char InstancesGeneratorVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <InstancesGenerator/PublicHeader.h>


